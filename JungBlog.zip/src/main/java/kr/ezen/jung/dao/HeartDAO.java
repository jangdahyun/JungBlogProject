package kr.ezen.jung.dao;

import java.sql.SQLException;

import org.apache.ibatis.annotations.Mapper;

import kr.ezen.jung.vo.HeartVO;
@Mapper
public interface HeartDAO {
	void insertHeart(HeartVO heartVO) throws SQLException;
	void deleteHeart(int userRef) throws SQLException;
	
}
