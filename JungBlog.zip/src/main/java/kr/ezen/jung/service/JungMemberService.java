package kr.ezen.jung.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import kr.ezen.jung.vo.JungMemberVO;

public interface JungMemberService extends UserDetailsService{

	JungMemberVO selectByUsername(String username);
	
	int selectCountByUsername(String username);
	
	void insert(JungMemberVO memberVO);
	
	void update(JungMemberVO memberVO);
	
	void delete(JungMemberVO memberVO);

	// 관리자 용
	List<JungMemberVO> getUsers();
	
	void updateRole(JungMemberVO memberVO);
}
