package kr.ezen.jung.service;

import java.io.UnsupportedEncodingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import lombok.extern.slf4j.Slf4j;

@Service(value = "mailService")
@Slf4j
public class MailServiceImpl implements MailService{
	
	@Autowired
	private JavaMailSender javaMailSender; // 메일을 보내기 위한 객체
	
	@Override
	public int mailSend(String to) {
		MailHandler mailHandler = null;
		int result = 0;
		try {
			mailHandler = new MailHandler(javaMailSender);
			
			mailHandler.setFrom("보내는 사람의 이매일", "jungBlogCompany");	// 누가
			mailHandler.setTo(to);												// 누구에게
			mailHandler.setSubject("jungBlog 회원가입 인증 번호");  			// 제목
			mailHandler.setText("여기가 인증번호인데..");						// 내용
			log.info("체크 1");
			mailHandler.send();	// 전송
			result = 1;
			log.info("메일 전송 성공!!!!!!");
		} catch (MessagingException e) {
			log.info("메일 전송 실패!!!!!!");
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			log.info("메일 전송 실패!!!!!!");
			e.printStackTrace();
		}
		return result;
	}

}
