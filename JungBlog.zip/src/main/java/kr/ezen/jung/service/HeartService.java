package kr.ezen.jung.service;

import kr.ezen.jung.vo.HeartVO;

public interface HeartService {
	void insertHeart(HeartVO heartVO);
	void deleteHeart(int userRef);
}
