package kr.ezen.jung.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ezen.jung.dao.HeartDAO;
import kr.ezen.jung.vo.HeartVO;

@Service
public class HeartServiceImpl implements HeartService{

	@Autowired
	private HeartDAO heartDAO;
	@Override
	public void insertHeart(HeartVO heartVO) {
		try {
			heartDAO.insertHeart(heartVO);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	@Override
	public void deleteHeart(int userRef) {
		try {
			heartDAO.deleteHeart(userRef);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}

}
