package kr.ezen.jung.service;

public interface MailService {
	public int mailSend(String to);
}
