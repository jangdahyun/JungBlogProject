package kr.ezen.jung.vo;

import lombok.Data;

@Data
public class JungFileBoardVO {
	private int idx;
	private String filepath;
	private String url;
	
	private int ref; //board idx
	
}
