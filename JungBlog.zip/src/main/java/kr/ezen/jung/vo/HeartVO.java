package kr.ezen.jung.vo;

import lombok.Data;

@Data
public class HeartVO {
	private int idx;
	private int userRef;
	private int boradRef;
	
}
