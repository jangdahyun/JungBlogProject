package kr.ezen.jung.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ezen.jung.service.JungMemberService;
import kr.ezen.jung.vo.JungMemberVO;

@Controller
@RequestMapping("/man")
public class JungMemberManController {

	@Autowired
	private JungMemberService jungMemberService;
	
	
	 // 리스트 타입으로 모든 유저 조회
    @GetMapping("/list")
    public String getUserList(Model model) {
        model.addAttribute("memberList", jungMemberService.getUsers());
        return "showMember"; 
    }
	
	  // 특정유저 조회 : 모델에 담아둠
    @GetMapping("/update/{username}")
    public String showUpdateForm(@PathVariable String username, Model model) {
        JungMemberVO memberVO = jungMemberService.selectByUsername(username);
        model.addAttribute("memberName", memberVO);
        return "/"; 
    }
}
