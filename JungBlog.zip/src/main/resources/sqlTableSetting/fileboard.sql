CREATE SEQUENCE jung_file_board_idx_seq;
CREATE table jung_file_board(
	idx NUMBER PRIMARY KEY ,
	REF NUMBER NOT null ,
	filepath varchar2(200) NOT null,
	url varchar2(4000) NOT null,

);

SELECT * FROM jung_file_board;