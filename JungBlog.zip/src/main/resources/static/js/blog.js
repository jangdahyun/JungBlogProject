$(function() {
   let time = $("#time").html();
   moment.locale('en');
   time = moment(time).format('ll');
   $("#time").html(time);
   
   
   document.querySelector("#heart").addEventListener('click',function(e){
      e.preventDefault();
      
      let heartCk = $("#heartCk").val();
      
      if(heartCk==0){
         axios.post('/heartUpload', {
             'boardRef': $("#boardIdx").val()
           })
           .then(function (res) {
             if(res.data=='1'){
               $("#heart").css('color','red')
               alert('조아요 성공')
            }
           })
           .catch(function (error) {
             console.log(error);
           });
      } else{
         // delete axios
      }
      
   })
})