package kr.ezen.jung;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JungBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
